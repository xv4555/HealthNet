from django.shortcuts import render, redirect, get_object_or_404, get_list_or_404
from django.utils import dateparse
from django.contrib.auth import logout, login, authenticate
from django.contrib.auth.decorators import login_required, user_passes_test
from django.http import HttpResponse
from .models import *
import datetime
import json
import time
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.admin.models import LogEntry


def user_login(request):
    """
    Checks if the user submitted a form
    If the request is a POST take the post data and and check if they have been filled out.
    Further... if the user is not logged in and tries to make a request against a protected route
    they will be redirected and the next key word will go into play.
    """

    if request.user.is_authenticated():
        return redirect('base_dashboard')

    if request.POST:
        next_redirect = request.POST.get('next')
        username = request.POST.get("username").lower()
        password = request.POST.get("password")

        if not all([password, username]):
            messages.add_message(request, messages.ERROR, 'Please enter username & password')
            return redirect('user_login')

        user = authenticate(username=username, password=password)

        if user is None:
            messages.add_message(request, messages.ERROR, 'Incorrect Username/Password')
            return redirect('user_login')

        login(request, user)

        if next_redirect:
            return redirect(next_redirect)

        return redirect('base_dashboard')

    return render(request, 'login.html')


def create_account(request):
    """
    This form takes the post data and creates the entire user profile such as medical information
    insurance information and so on.
    """
    if request.POST:
        result = create_account_form(request, request.POST)
        if result:
            return redirect('base_dashboard')

    hospitals = Hospital.objects.all()

    return render(request, 'create_account.html', {'hospitals': hospitals})


def create_account_form(request, post):
    """
    This is the method that actually handles the authentication and login functions which are
    the default django authentication system.
    """
    username = post.get("username")
    first_name = post.get("first_name")
    last_name = post.get("last_name")
    email = post.get("email")

    phone_number = post.get("phone")

    password = post.get("password")

    height = float(post.get("height"))
    weight = float(post.get("weight"))
    sex = post.get("sex")

    current_medications = post.get("medications")
    allergies = post.get("allergies")
    medical_conditions = post.get("medical_conditions")
    family_history = post.get("family_history")
    additional_info = post.get("additional_info")
    primary_hospital = Hospital.objects.get(pk=post.get("primary_hospital"))

    policy_number = int(post.get("policy_number"))
    company = post.get("company")

    if User.objects.filter(username=username).exists():
        messages.add_message(request, messages.ERROR, 'User already exists!')
        return False

    else:
        new_user = User.objects.create_user(
            username=username, password=password,
            first_name=first_name, last_name=last_name, email=email
        )

        new_user_profile = UserProfile.objects.create(
            user=new_user,
            phone_number=phone_number, status=UserStatus.objects.get(pk=3)
        )

        medical_info = MedicalInformation.objects.create(
            height=height, weight=weight, sex=sex,
            medical_conditions=medical_conditions,
            allergies=allergies, medications=current_medications,
            family_history=family_history, additional_info=additional_info,
            user=new_user_profile, primary_hospital=primary_hospital
        )

        insurance = Insurance.objects.create(
            policy_number=policy_number, company=company, medical_information=medical_info,
        )

    return True


@login_required
def log_out(request):
    """
    This flushes out the user object from the session which in turn logs the user out.
    """
    logout(request)
    return redirect('user_login')


@login_required
def base_dashboard(request):
    """
    This is the system that first includes the specific dashboards based on what type the user is.
    """
    appointments = None

    if request.user.userprofile.is_patient():
        appointments = Appointment.objects.filter(patient=request.user.id).order_by('date')
    elif request.user.userprofile.is_doctor():
        appointments = Appointment.objects.filter(doctor=request.user.id).order_by('date')

    return render(request, 'base_dashboard.html', {'appointments': appointments, 'the_user': request.user})


@login_required
def create_appointment(request):
    """
   This function creates an appointment but however it is ill-implemented.
   """
    dates = get_dates()
    users = User.objects.all()

    if request.POST:
        new_appointment = create_appointment_form(request, request.POST)
        if new_appointment:
            redirect('view_appointments')

    return render(request, 'create_appointment.html', {'the_user': request.user,
                                                       'dates': dates,
                                                       'users': users,
                                                       'hours': range(1, 13),
                                                       'minutes': range(1, 60)})


def get_dates():
    """
    Helper function to get dates in an iterrable way.
    """
    return {
        "years": range(datetime.date.today().year, datetime.date.today().year + 5),
        "months": range(1, 13),
        "days": range(1, 32)
    }


def create_appointment_form(request, post):
    """
   This code creates a new appoint object. Based on what type of user it is the
   user can either be a doctor or a patient.
   """
    # string_date = "{0}-{1}-{2}".format(year, month, day)
    # date = datetime.datetime.strptime(string_date, '%Y-%m-%d').date()
    new_appointment = None
    date_string = post.get("date") + "-" + post.get("time")
    date = datetime.datetime.strptime(date_string, '%Y-%m-%d-%H:%M')
    the_user = request.user
    notes = post.get("notes")

    if the_user.userprofile.is_doctor():
        patient_id = int(post.get("patient", the_user.pk))
        patient = User.objects.get(pk=patient_id)
        doctor = User.objects.get(pk=the_user.id)
        new_appointment = Appointment.objects.create(date=date, doctor=doctor, patient=patient, notes=notes)

    elif request.user.userprofile.is_patient():
        doctor_id = int(post.get("doctor", the_user.pk))
        doctor = User.objects.get(pk=doctor_id)
        patient = User.objects.get(pk=the_user.id)
        new_appointment = Appointment.objects.create(date=date, doctor=doctor, patient=patient, notes=notes)

    return new_appointment


@login_required
def view_appointments(request):
    """
   This method shows all appointments specifically if your a patient.
    """

    appointments = None

    if request.user.userprofile.is_patient():
        appointments = Appointment.objects.filter(patient=request.user.id).order_by('date')

    elif request.user.userprofile.is_doctor():
        appointments = Appointment.objects.filter(doctor=request.user.id).order_by('date')

    return render(request, 'view_appointments.html', {'appointments': appointments,
                                                      'the_user': request.user})


@login_required
def cancel_appointment(request, id):
    """
    The cancel appointment method just deletes the appointment object from the appointment model.
    """
    appointment = get_object_or_404(Appointment, pk=id)

    if request.POST:
        appointment.delete()
        messages.add_message(request, messages.ERROR, 'Appointment cancled')
        return redirect('view_appointments')

    return render(request, 'cancel_appointment.html', {'appointment': appointment})


@login_required
def edit_basic_info(request):
    """
    This method will take basic information such as last, first and email.
    """
    if request.POST:
        request.user.first_name = request.POST['first_name']
        request.user.last_name = request.POST['last_name']
        request.user.email = request.POST['email']
        request.user.save()
        request.user.userprofile.phone_number = request.POST['phone']
        request.user.userprofile.save()

        return redirect('edit_basic_info')

    return render(request, 'edit_basic_info.html', {'the_user': request.user})


@login_required
def edit_medical_info(request):
    """
    This method will update the medical information for the patient.
    """
    if request.POST:
        post = request.POST
        the_user = request.user
        the_user.userprofile.medicalinformation.height = float(post.get("height"))
        the_user.userprofile.medicalinformation.weight = float(post.get("weight"))
        the_user.userprofile.medicalinformation.sex = post.get("sex")
        the_user.userprofile.medicalinformation.medications = post.get("medications")
        the_user.userprofile.medicalinformation.allergies = post.get("allergies")
        the_user.userprofile.medicalinformation.medical_conditions = post.get("medical_conditions")
        the_user.userprofile.medicalinformation.family_history = post.get("family_history")
        the_user.userprofile.medicalinformation.additional_info = post.get("additional_info")
        the_user.userprofile.medicalinformation.primary_hospital = Hospital.objects.get(pk=post.get("primary_hospital"))
        the_user.userprofile.medicalinformation.save()

        return redirect('edit_medical_info')

    hospitals = Hospital.objects.all()
    return render(request, 'edit_medical_info.html', {'the_user': request.user, 'hospitals': hospitals})


@login_required
def view_insurances(request):
    """
    This will show views of the insurance providers available to the user.
    There can be multiple insurance providers/policy numbers for a user.
    """
    insurance = Insurance.objects.filter(medical_information=request.user.userprofile.medicalinformation)
    return render(request, 'view_insurances.html', {'insurances': insurance})


@login_required
def view_insurance(request, insurance_id):
    if request.POST:
        post = request.POST
        insurance = Insurance.objects.get(pk=insurance_id)
        insurance.policy_number = post.get("policy_number")
        insurance.company = post.get("company")
        insurance.save()

        return redirect('view_insurance', insurance_id=insurance_id)

    insurance = Insurance.objects.get(pk=insurance_id)
    return render(request, 'view_insurance.html', {'insurance': insurance})


@login_required
def add_hospital(request):
    """
    This adds a new hospital to the system.
    """
    if request.POST:
        post = request.POST
        name = post.get("name")
        address = post.get("address")
        city = post.get("city")
        state = post.get("state")
        zip = post.get("zip")
        hospital = Hospital.objects.create(
            name=name,
            address=address,
            city=city,
            state=state,
            zip=zip
        )

        if hospital:
            return redirect('add_hospital')

    return render(request, 'add_hospital.html')


@login_required
def add_doctor(request):
    """
    This adds a new user of the type doctor
    """
    if request.POST:
        post = request.POST
        username = post.get("username")
        first_name = post.get("first_name")
        last_name = post.get("last_name")
        email = post.get("email")
        password = post.get("password")

        new_user = User.objects.create_user(
            username=username,
            password=password,
            first_name=first_name,
            last_name=last_name,
            email=email
        )
        new_user_profile = UserProfile.objects.create(
            user=new_user,
            status=UserStatus.objects.get(pk=1)
        )

        if new_user:
            return redirect('add_doctor')

    return render(request, 'add_doctor.html')


@login_required
def add_nurse(request):
    """
    This method will add a new nurse to the system.
    """
    if request.POST:
        post = request.POST
        username = post.get("username")
        first_name = post.get("first_name")
        last_name = post.get("last_name")
        email = post.get("email")
        password = post.get("password")

        new_user = User.objects.create_user(
            username=username,
            password=password,
            first_name=first_name,
            last_name=last_name,
            email=email
        )

        new_user_profile = UserProfile.objects.create(
            user=new_user,
            status=UserStatus.objects.get(pk=2)
        )

        if new_user:
            return redirect('add_nurse')

    return render(request, 'add_nurse.html')


@login_required
def add_admin(request):
    """
    This will add an admin user to the system.
    """
    if request.POST:
        post = request.POST
        username = post.get("username")
        first_name = post.get("first_name")
        last_name = post.get("last_name")
        email = post.get("email")
        password = post.get("password")

        new_user = User.objects.create_user(
            username=username,
            password=password,
            first_name=first_name,
            last_name=last_name,
            email=email
        )
        new_user_profile = UserProfile.objects.create(
            user=new_user,
            status=UserStatus.objects.get(pk=4)
        )

        if new_user and new_user_profile:
            return redirect('add_admin')

    return render(request, 'add_admin.html')


@login_required
def message_center(request, url):
    """View the message center"""

    if request.POST and url is not 'sent':
        message = Message.objects.get(id=request.POST.get("message_id"))
        if message.read:
            message.read = 0
            message.save()
        else:
            message.read = 1
            message.save()

    all_messages = Message.objects.all().order_by("-time")
    user_messages = []
    section = "all"
    if url is 'read':
        section = "read"
        for m in all_messages:
            if m.user_to.__str__() in request.user.userprofile.get_full_name() and m.read:
                user_messages.append(m)

    elif url is 'unread':
        section = "unread"
        for m in all_messages:
            if m.user_to.__str__() in request.user.userprofile.get_full_name() and not m.read:
                user_messages.append(m)

    elif url is 'sent':
        section = "sent"
        for m in all_messages:
            if m.user_from.__str__() in request.user.userprofile.get_full_name():
                user_messages.append(m)

    elif url is 'all':
        for m in all_messages:
            if m.user_to.__str__() in request.user.userprofile.get_full_name():
                user_messages.append(m)

    elif url is 'compose':
        section = 'compose'

    the_users = UserProfile.objects.exclude(user=request.user)

    return render(request, 'message_center.html', {'messages': user_messages, 'the_users': the_users,
                                                   'display': section})


@login_required
def view_message(request, message_id):
    message = Message.objects.get(pk=message_id)

    return render(request, 'view_message.html', {'message': message})


@login_required
def send_message(request):
    if request.POST:
        post = request.POST

        user_from = request.user.userprofile
        user_to = UserProfile.objects.get(id=post.get("user_to"))
        subject = post.get("subject")
        message = post.get("message")

        message_created = Message.objects.create(user_from=user_from, user_to=user_to,
                                                 subject=subject, message=message,
                                                 time=timezone.now(), read=0)

        if message_created:
            return redirect('sent')

    return render(request, 'message_center.html')


@login_required
def update_message(request, message_id):

    message = Message.objects.get(id=message_id)
    if message.read:
        message.read = 0
    else:
        message.read = 1

    return redirect('all')


@login_required
def view_logs(request):
    """View the system logs """
    keyword = "Search"
    num_logs = 0
    logs = LogEntry.objects.all()
    if request.POST:
        keyword = request.POST.get("search")
        if keyword:
            logs = []
            for log in LogEntry.objects.all():
                if keyword in log.__str__() or keyword in log.user.__str__():
                    logs.append(log)
                    num_logs += 1

    return render(request, 'view_logs.html', {'logs': logs, "keyword": keyword, "num_logs": num_logs})


@login_required
def view_log(request, log_id):
    """Delete the system log"""

    if request.POST:
        LogEntry.objects.filter(pk=log_id).delete()
        return redirect('view_logs')

    log = LogEntry.objects.get(pk=log_id)
    return render(request, 'view_log.html', {'log': log})


@login_required
def admit_patient(request):
    if request.POST:
        post = request.POST

        doctor = None
        nurse = None

        if request.user.userprofile.is_doctor():
            nurse = UserProfile.objects.get(id=post.get("nurse"))
            doctor = UserProfile.objects.get(id=request.user.userprofile.id)

        elif request.user.userprofile.is_nurse():
            nurse = UserProfile.objects.get(id=request.user.userprofile.id)
            doctor = UserProfile.object.get(id=post.get("doctor"))

        patient = UserProfile.objects.get(id=post.get("patient"))
        hospital = Hospital.objects.get(hospital_id=post.get("hospital"))

        saved = HospitalStay.objects.create(patient=patient, hospital=hospital,
                                            doctor=doctor, nurse=nurse)

        if saved:
            return redirect('admit_patient')

    patients = UserProfile.objects.filter(status=3)
    nurses = UserProfile.objects.filter(status=2)
    doctors = UserProfile.objects.filter(status=1)

    your_stays = HospitalStay.objects.filter(nurse=request.user.userprofile, discharge__isnull=True) | \
                 HospitalStay.objects.filter(doctor=request.user.userprofile, discharge__isnull=True)

    archives = HospitalStay.objects.filter(discharge__isnull=False)
    hospital = HospitalStaff.objects.filter(user_profile=request.user.userprofile)
    all_stays = HospitalStay.objects.filter(discharge__isnull=True,
                                            id__in=hospital.filter(user_profile=request.user.userprofile).values_list(
                                                'hospital_id', flat=True))

    return render(request, 'admit_patient.html', {'patients': patients, 'all_stays': all_stays,
                                                  'your_stays': your_stays, 'hospitals': hospital,
                                                  'nurses': nurses, 'doctors': doctors,
                                                  'archives': archives})


def discharge_patient(request, id):
    if request.POST:
        HospitalStay.objects.filter(id=id).update(discharge=timezone.now())

    return redirect('admit_patient')


def patient_transfer(request, id=None):
    if request.POST and id is not None:
        post = request.POST
        patient = UserProfile.objects.get(pk=post.get("patient_id"))
        from_hospital = Hospital.objects.get(pk=post.get("transfer_from"))
        to_hospital = Hospital.objects.get(pk=post.get("transfer_to"))

        Transfers.objects.create(transfer_patient=patient,
                                 from_hospital=from_hospital,
                                 to_hospital=to_hospital,
                                 date_accepted=timezone.now(),
                                 receiver=request.user.userprofile)

        HospitalStay.objects.filter(id=id).update(hospital=to_hospital)

        return redirect('patient_transfer')

    your_hospitals = HospitalStaff.objects.filter(user_profile=request.user.userprofile)
    all_stays = HospitalStay.objects.exclude(hospital__in=your_hospitals.values_list('hospital_id', flat=True))

    return render(request, 'patient_transfer.html', {'all_stays': all_stays, 'your_hospitals': your_hospitals})


def prescriptions(request):
    if request.POST:
        post = request.POST
        patient = UserProfile.objects.get(post.get("patient"))
        doctor = request.user
        name = post.get("name")
        description = post.get("description")
        notes = post.get("notes")
        instructions = post.get("instructions")
        dosage = post.get("dosage")

        #Prescription.objects.create()

    all_prescriptions = None
    your_prescriptions = None
    medical_informations = None

    if request.user.userprofile.is_doctor():
        all_prescriptions = Prescription.objects.all()
        your_prescriptions = Prescription.objects.filter(doctor=request.user)

    if request.user.userprofile.is_nurse():
        your_hospitals = HospitalStaff.objects.filter(user_profile=request.user.userprofile)
        medical_informations = MedicalInformation.objects.filter(
            primary_hospital__in=your_hospitals.values_list('hospital_id', flat=True))

    patients = UserProfile.objects.filter(status=3)
    return render(request, 'prescriptions.html', {'prescriptions': all_prescriptions,
                                                  'medical_informations': medical_informations,
                                                  'your_prescriptions': your_prescriptions,
                                                  'patients': patients})
